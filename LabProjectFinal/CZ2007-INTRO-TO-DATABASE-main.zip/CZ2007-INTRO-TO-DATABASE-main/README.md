# CZ2007-INTRO-TO-DATABASE

https://lucid.app/lucidchart/046dcce0-7898-49f0-bca6-5856748deedd/edit?viewport_loc=-2439%2C-1151%2C4055%2C1741%2C0_0&invitationId=inv_a8b5f032-9a63-4a36-a2a4-34ee0143bb21
